﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using product_service.DTOs;
using System.Security.Claims;

[ApiController]
[Route("api/[controller]")]
public class ProductsController : ControllerBase
{
    private readonly IProductService _service;

    public ProductsController(IProductService service)
    {
        _service = service;
    }

    [HttpGet]
    public async Task<IActionResult> GetAll(int page = 1, int pageSize = 10, string? ProductName = null)
    {
        var (data, total) = await _service.GetAllAsync(page, pageSize, ProductName);

        return Ok(new ApiResponse<object>
        {
            Success = true,
            Message = "Products fetched successfully",
            Data = new
            {
                TotalCount = total,
                Page = page,
                PageSize = pageSize,
                Items = data
            }
        });
    }

    [HttpGet("{id:int}")]
    public async Task<IActionResult> GetById(int id)
    {
        var item = await _service.GetByIdAsync(id);

        if (item == null)
        {
            return NotFound(new ApiResponse<string>
            {
                Success = false,
                Message = $"Product with ID {id} not found"
            });
        }

        return Ok(new ApiResponse<ProductDto>
        {
            Success = true,
            Message = "Product fetched successfully",
            Data = item
        });
    }

    [HttpPost]
    public async Task<IActionResult> Create([FromBody] CreateProductDto dto)
    {
        var userIdClaim = User.FindFirst("UserId")?.Value;
        int userId = int.Parse(userIdClaim!);

        if (!ModelState.IsValid)
        {
            return BadRequest(new ApiResponse<object>
            {
                Success = false,
                Message = "Validation failed",
                Data = ModelState
            });
        }

        var product = await _service.CreateAsync(dto, userId);

        return CreatedAtAction(nameof(GetById), new { id = product.ProductId },
            new ApiResponse<ProductDto>
            {
                Success = true,
                Message = "Product created successfully",
                Data = product
            });
    }

    [HttpPut("{id:int}")]
    public async Task<IActionResult> Update(int id, [FromBody] UpdateProductDto dto)
    {
        if (!ModelState.IsValid)
        {
            return BadRequest(new ApiResponse<object>
            {
                Success = false,
                Message = "Validation failed",
                Data = ModelState
            });
        }
        var userId = int.Parse(User.FindFirst("UserId")!.Value);

        
        var result = await _service.UpdateAsync(id, dto, userId);

        if (!result)
        {
            return NotFound(new ApiResponse<string>
            {
                Success = false,
                Message = $"Product with ID {id} not found"
            });
        }

        return Ok(new ApiResponse<string>
        {
            Success = true,
            Message = "Product updated successfully"
        });
    }

    [HttpDelete("{id:int}")]
    public async Task<IActionResult> Delete(int id)
    {

        var userId = int.Parse(User.FindFirst("UserId")!.Value);
        var result = await _service.DeleteAsync(id, userId);

        if (!result)
        {
            return NotFound(new ApiResponse<string>
            {
                Success = false,
                Message = $"Product with ID {id} not found"
            });
        }

        return Ok(new ApiResponse<string>
        {
            Success = true,
            Message = "Product deleted successfully"
        });
    }
}