﻿using System.Diagnostics;

namespace product_service.Middleware
{
    public class PerformanceMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly ILogger<PerformanceMiddleware> _logger;

        public PerformanceMiddleware(RequestDelegate next, ILogger<PerformanceMiddleware> logger)
        {
            _next = next;
            _logger = logger;
        }

        public async Task InvokeAsync(HttpContext context)
        {
            var stopwatch = Stopwatch.StartNew();

            await _next(context);

            stopwatch.Stop();

            var elapsed = stopwatch.ElapsedMilliseconds;

            _logger.LogInformation(
                "Request {Method} {Path} executed in {ElapsedTime} ms",
                context.Request.Method,
                context.Request.Path,
                elapsed
            );
        }
    }
}
