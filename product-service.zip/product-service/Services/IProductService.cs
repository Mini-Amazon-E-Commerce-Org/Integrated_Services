﻿public interface IProductService
{
    Task<(List<ProductDto> Items, int TotalCount)> GetAllAsync(int page, int pageSize, string? search); Task<ProductDto?> GetByIdAsync(int id);
    Task<ProductDto> CreateAsync(CreateProductDto dto, int userId);
    Task<bool> UpdateAsync(int id, UpdateProductDto dto, int userId);
    Task<bool> DeleteAsync(int id, int userId);
}