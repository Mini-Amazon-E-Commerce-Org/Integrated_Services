﻿using Microsoft.EntityFrameworkCore;
using product_service.Models;

public class ProductService : IProductService
{
    private readonly IProductRepository _repo;
    private readonly ILogger<ProductService> _logger;

    public ProductService(IProductRepository repo, ILogger<ProductService> logger)
    {
        _repo = repo;
        _logger = logger;
    }

    public async Task<(List<ProductDto> Items, int TotalCount)> GetAllAsync(int page, int pageSize, string? search)
    {
        _logger.LogInformation("Fetching products | Page: {Page}, PageSize: {PageSize}, Search: {Search}", page, pageSize, search);

        var query = _repo.Query();

        query = query.Where(p => p.IsActive);

        if (!string.IsNullOrEmpty(search))
        {
            _logger.LogInformation("Applying search filter: {Search}", search);
            query = query.Where(p => p.Name.Contains(search));
        }

        var totalCount = await query.CountAsync();
        _logger.LogInformation("Total active products found: {Count}", totalCount);

        var products = await query
            .OrderBy(p => p.ProductId)
            .Skip((page - 1) * pageSize)
            .Take(pageSize)
            .ToListAsync();

        var result = products.Select(p => Map(p)).ToList();

        _logger.LogInformation("Returning {Count} products", result.Count);

        return (result, totalCount);
    }

    public async Task<List<ProductDto>> GetAllAsync()
    {
        _logger.LogInformation("Fetching all products (non-paginated)");

        var items = await _repo.GetAllAsync();

        _logger.LogInformation("Total products fetched: {Count}", items.Count);

        return items.Select(p => Map(p)).ToList();
    }

    public async Task<ProductDto?> GetByIdAsync(int id)
    {
        _logger.LogInformation("Fetching product by Id: {ProductId}", id);

        var p = await _repo.GetByIdAsync(id);

        if (p == null || !p.IsActive)
        {
            _logger.LogWarning("Product not found with Id: {ProductId}", id);
            return null;
        }

        _logger.LogInformation("Product found with Id: {ProductId}", id);

        return Map(p);
    }

    public async Task<ProductDto> CreateAsync(CreateProductDto dto, int userId)
    {
        _logger.LogInformation("Creating new product: {ProductName}", dto.Name);

        var entity = new Product
        {
            Name = dto.Name,
            Description = dto.Description,
            Price = dto.Price,
            StockQuantity = dto.StockQuantity,
            CreatedAt = DateTime.UtcNow,
            CreatedBy = userId
        };

        var created = await _repo.AddAsync(entity);

        _logger.LogInformation("Product created successfully with Id: {ProductId}", created.ProductId);

        return Map(created);
    }

    public async Task<bool> UpdateAsync(int id, UpdateProductDto dto, int userId)
    {
        _logger.LogInformation("Updating product with Id: {ProductId}", id);

        var existing = await _repo.GetByIdAsync(id);

        if (existing == null || !existing.IsActive)
        {
            _logger.LogWarning("Update failed. Product not found with Id: {ProductId}", id);
            return false;
        }

        existing.Name = dto.Name;
        existing.Description = dto.Description;
        existing.Price = dto.Price;
        existing.StockQuantity = dto.StockQuantity;
        existing.IsActive = dto.IsActive;
        existing.UpdatedAt = DateTime.UtcNow;
        existing.UpdatedBy = userId; 

        await _repo.UpdateAsync(existing);

        _logger.LogInformation("Product updated successfully with Id: {ProductId}", id);

        return true;
    }

    public async Task<bool> DeleteAsync(int id, int userId)
    {
        _logger.LogInformation("Deleting (soft) product with Id: {ProductId}", id);

        var product = await _repo.GetByIdAsync(id);

        if (product == null || !product.IsActive)
        {
            _logger.LogWarning("Delete failed. Product not found with Id: {ProductId}", id);
            return false;
        }

        product.IsActive = false;
        product.UpdatedAt = DateTime.UtcNow;
        product.UpdatedBy = userId;

        await _repo.UpdateAsync(product);

        _logger.LogInformation("Product soft-deleted successfully with Id: {ProductId}", id);

        return true;
    }

    private static ProductDto Map(Product p) => new()
    {
        ProductId = p.ProductId,
        Name = p.Name,
        Description = p.Description,
        Price = p.Price,
        StockQuantity = p.StockQuantity,
        IsActive = p.IsActive
    };
}