﻿using System.ComponentModel.DataAnnotations;

public class CreateProductDto
{
    [Required, MaxLength(150)]
    public string Name { get; set; } = null!;

    public string? Description { get; set; }

    [Range(0.01, double.MaxValue)]
    public decimal Price { get; set; }

    [Range(0, int.MaxValue)]
    public int StockQuantity { get; set; }
}